package com.helper.project.dto;

import java.util.List;

public class Deployment {
    private List<String> pipelines;
    private String env;

    public List<String> getPipelines() {
        return pipelines;
    }
    public void setPipelines(List<String> pipelines) {
        this.pipelines = pipelines;
    }

    public String getEnv() {
        return env;
    }
    public void setEnv(String env) {
        this.env = env;
    }
}
