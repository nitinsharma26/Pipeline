package com.helper.project.constant;

public enum MicroserviceMapping {

    // Enum constants with key-value pairs (microservice name : project ID)
    SUBSCRIBER_RATE_PLAN("subscriber-rate-plan-ms-v1", "project_id_123"),
    ACCOUNT_MANAGEMENT("account-management-ms", "project_id_456"),
    ORDER_MANAGEMENT("order-management-ms", "project_id_789");

    private final String microserviceName;
    private final String projectId;

    // Constructor
    MicroserviceMapping(String microserviceName, String projectId) {
        this.microserviceName = microserviceName;
        this.projectId = projectId;
    }

    // Getter methods for key-value pairs
    public String getMicroserviceName() {
        return microserviceName;
    }

    public String getProjectId() {
        return projectId;
    }

    // Static method to find project ID by microservice name
    public static String getProjectIdByMicroserviceName(String microserviceName) {
        for (MicroserviceMapping mapping : MicroserviceMapping.values()) {
            if (mapping.getMicroserviceName().equalsIgnoreCase(microserviceName)) {
                return mapping.getProjectId();
            }
        }
        return null; // Return null if the microservice is not found
    }
}
