package com.helper.project.dto;

import java.util.List;

public class DeploymentRequest {
    private List<Deployment> deploymentRequest;

    // Getters and setters
    public List<Deployment> getDeploymentRequest() {
        return deploymentRequest;
    }
    public void setDeploymentRequest(List<Deployment> deploymentRequest) {
        this.deploymentRequest = deploymentRequest;
    }
}