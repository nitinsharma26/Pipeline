package com.helper.project.constant;

public enum Environment {
     qat01,qat02;
}
