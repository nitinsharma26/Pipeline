package com.helper.project.service;

import com.helper.project.rest.GitLabFeignClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class GitLabJobService {

    @Autowired
    private GitLabFeignClient gitLabFeignClient;

    /**
     * Fetches the job ID from GitLab by job name.
     *
     * @param privateToken The GitLab private token for authentication.
     * @param projectId The ID of the project.
     * @param pipelineId The ID of the pipeline.
     * @param jobName The name of the job to search for.
     * @return The job ID if found, or -1 if not found.
     */
    public long fetchJobId(String privateToken, String projectId, String pipelineId, String jobName) {
        // Fetch jobs JSON from GitLab using Feign client
        String jsonResponse = gitLabFeignClient.getJobs(privateToken, projectId, pipelineId);

        // Parse JSON response
        JSONArray jobs = new JSONArray(jsonResponse);

        // Iterate over the jobs array and search for the job with the given name
        for (int i = 0; i < jobs.length(); i++) {
            JSONObject job = jobs.getJSONObject(i);
            String currentJobName = job.getString("name");

            if (currentJobName.equalsIgnoreCase(jobName)) {
                return job.getLong("id"); // Return the job ID if found
            }
        }

        // Return -1 if the job with the specified name is not found
        return -1;
    }
}
