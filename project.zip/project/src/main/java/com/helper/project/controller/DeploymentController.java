package com.helper.project.controller;
import com.helper.project.dto.DeploymentRequest;
import com.helper.project.service.DeploymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class DeploymentController{
    @Autowired
    private DeploymentService deploymentService;
    @PostMapping("/scheduleDeployment")
    public String scheduleDeployment(@RequestBody DeploymentRequest deploymentRequest) {
        deploymentService.schedule(deploymentRequest);
        return "Scheduled";
    }
}
