package com.helper.project.dto;

import jakarta.persistence.*;

@Entity
@Table(name = "scheduled_pipelines")
public class ScheduledPipeline {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Assuming there's an auto-generated primary key
    private Long id;

    @Column(name = "pipelines", nullable = false)
    private String pipelines;

    @Column(name = "project_id", nullable = false)
    private String projectId;

    @Column(name = "job_id", nullable = true)  // Nullable if job_id is optional
    private String jobId;

    @Column(name = "pipeline_id", nullable = false)
    private String pipelineId;

    // Default constructor
    public ScheduledPipeline() {
    }

    // Constructor with parameters
    public ScheduledPipeline(String pipelines, String projectId, String jobId, String pipelineId) {
        this.pipelines = pipelines;
        this.projectId = projectId;
        this.jobId = jobId;
        this.pipelineId = pipelineId;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPipelines() {
        return pipelines;
    }

    public void setPipelines(String pipelines) {
        this.pipelines = pipelines;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getPipelineId() {
        return pipelineId;
    }

    public void setPipelineId(String pipelineId) {
        this.pipelineId = pipelineId;
    }
}
