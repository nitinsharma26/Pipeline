package com.helper.project.service;

import com.helper.project.constant.MicroserviceMapping;
import com.helper.project.dto.Deployment;
import com.helper.project.dto.DeploymentRequest;
import com.helper.project.dto.ScheduledPipeline;
import com.helper.project.repository.DeploymentRepository;
import com.helper.project.rest.GitLabFeignClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DeploymentService {

    @Autowired
    private GitLabFeignClient gitLabFeignClient;

    @Autowired
    private DeploymentRepository deploymentRepository;
    public void schedule(DeploymentRequest deploymentRequest) {
     //https://gitlab.com/tmobile/adms/ms/subscriber-rate-plan-ms-v1/-/pipelines/1562420968
        for (Deployment deployment : deploymentRequest.getDeploymentRequest()) {
            String pipelineId,projectId,jobId,privateToken="235423";
            for (String pipeline : deployment.getPipelines()) {

                pipelineId = extractPipelineId(pipeline);
                projectId = extractProjectId(pipeline);
                jobId = fetchJobId(privateToken,projectId,pipelineId,"deploy-Qat01");
               
                ScheduledPipeline scheduledPipeline = new ScheduledPipeline();
                scheduledPipeline.setJobId(jobId);
                scheduledPipeline.setPipelines(pipeline);
                scheduledPipeline.setPipelineId(pipelineId);
                scheduledPipeline.setProjectId(projectId);
                deploymentRepository.save(scheduledPipeline);
            }
        }
    }

    private String fetchJobId(String privateToken, String projectId, String pipelineId,String env) {
        String jsonResponse = gitLabFeignClient.getJobs(privateToken, projectId, pipelineId);

        // Parse JSON response
        JSONArray jobs = new JSONArray(jsonResponse);

        String JobId = null;

        // Iterate over the jobs array and search for the job with the given name
        for (int i = 0; i < jobs.length(); i++) {
            JSONObject job = jobs.getJSONObject(i);
            String currentJobName = job.getString("name");

            if (currentJobName.equalsIgnoreCase(env)) {
                JobId = String.valueOf(job.getLong("id")); // Return the job ID if found
                return JobId;
            }
        }

        // Return -1 if the job with the specified name is not found
        return JobId;
    }

    private String extractProjectId(String pipeline) {
        String microservicePattern = "/([^/]+)/-/pipelines";
        Pattern msPattern = Pattern.compile(microservicePattern);
        Matcher msMatcher = msPattern.matcher(pipeline);
        String microserviceName = null;
        if (msMatcher.find()) {
            microserviceName = msMatcher.group(1);
        }
        return MicroserviceMapping.getProjectIdByMicroserviceName(microserviceName);
    }

    private String extractPipelineId(String pipeline) {
        String pipelineIdPattern = "/pipelines/(\\d+)";
        Pattern pipelinePattern = Pattern.compile(pipelineIdPattern);
        Matcher pipelineMatcher = pipelinePattern.matcher(pipeline);
        String pipelineId = null;
        if (pipelineMatcher.find()) {
            pipelineId = pipelineMatcher.group(1);
        }
        return pipelineId;
    }

    // Cron expression: At 8 AM every day IST (IST is UTC+5:30)
    @Scheduled(cron = "0 0 8 * * ?", zone = "Asia/Kolkata")
    public void scheduleJob() {
        System.out.println("Fetching scheduled pipelines at 8 AM IST...");

        // Fetch all scheduled pipelines from the database
        List<ScheduledPipeline> scheduledPipelines = deploymentRepository.findAll();

        // Process each scheduled pipeline
        for (ScheduledPipeline pipeline : scheduledPipelines) {
            deployPipeline(pipeline);
        }
    }

    // Simulate the deployment process
    private void deployPipeline(ScheduledPipeline pipeline) {
        // Add the logic to deploy the pipeline
        System.out.println("Deploying pipeline: " + pipeline.getPipelineId() +
                " for project: " + pipeline.getProjectId() +
                " with job ID: " + pipeline.getJobId());

        // Logic for deploying the pipeline, can involve calling an external service or executing the job
    }

    private String getProjectIdFromPipeline(String pipeline) {
        // Dummy logic to extract project_id from pipeline
        return "432542354";  // You can replace this with actual logic
    }
}
