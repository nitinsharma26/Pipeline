package com.helper.project.rest;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "gitlabClient", url = "https://gitlab.com/api/v4")
public interface GitLabFeignClient {

    @GetMapping("/projects/{projectId}/pipelines/{pipelineId}/jobs?pagination=keyset&per_page=100&order_by=id&sort=asc")
    String getJobs(
            @RequestHeader("PRIVATE-TOKEN") String privateToken,
            @PathVariable("projectId") String projectId,
            @PathVariable("pipelineId") String pipelineId
    );
}

